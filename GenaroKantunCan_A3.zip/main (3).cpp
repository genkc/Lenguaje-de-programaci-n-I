/******************************************************************************

Programa para generar el RFC de los empleados de la empresa AMC.
autor: Genaro Kantun Can.
fecha: 07-08-2025

*******************************************************************************/
#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <algorithm>

using namespace std;

const vector<string>palabrasprohibidas={
    "PENE","POPO", "CACA", "PUTA", "PUTO","LOCO", "LOCA", "PITO"
};
     string corregirRFC(const string& RFC){
      for(const string& palabra: palabrasprohibidas){
          if (RFC==palabra){
              return RFC.substr(0,3) + "X";
              }
      }
      return RFC;
  }
 char obtenerprimeravocalinterna (const string&str){
     for(size_t i=1; i<str.length(); ++i){
         char c= toupper (str[i]);
         if (c=='A'||c=='E'||c=='I'||c=='O'||c=='U');
         return c;
        }
        return 'x';
 }
     string calcularRFC(string nombre, string apellidoPaterno, string apellidoMaterno, int dia, int mes, int anio){
     transform(nombre.begin(), nombre.end(), nombre.begin(), ::toupper);
     transform(apellidoPaterno.begin(), apellidoPaterno.end(), apellidoPaterno.begin(), ::toupper);
     transform(apellidoMaterno.begin(), apellidoMaterno.end(), apellidoMaterno.begin(), ::toupper);
     char letrainicial=apellidoPaterno[0];
     char primeravocalinterna = obtenerprimeravocalinterna(apellidoPaterno);
     char inicialapellidomaterno=(!apellidoMaterno.empty())? apellidoMaterno[0] : 'x';
     char inicialnombre=nombre[0];
     
     string rfc;
     rfc=letrainicial;
     rfc +=primeravocalinterna;
     rfc +=inicialapellidomaterno;
     rfc +=inicialnombre;
     rfc = corregirRFC(rfc);
     char fecha[10];
     sprintf(fecha, "%02d%02d%02d", anio % 100, mes, dia);
     rfc += fecha;
     return rfc;
 }
     int main(){
         char salir;
         string nombre, apellidoPaterno, apellidoMaterno;
         int dia, mes, anio;
    
     cout<<"Calculo de RFC"<<endl;
     cout<<"Introduce tu nombre:  ";
     getline(cin, nombre);
     cout<<"Introduce tu apellido paterno:  ";
     getline(cin, apellidoPaterno);
     cout<<"Introduce tu apellido materno (en caso de no tener, presione Enter):  ";
     getline(cin, apellidoMaterno);
     cout<<"Introduce tu fecha de nacimiento(solo números)";
     cout<<"\nDía: ";
     cin>> dia;
     cout<<"Mes: ";
     cin>> mes;
     cout<<"Año: ";
     cin>> anio;
     string rfc=calcularRFC(nombre, apellidoPaterno, apellidoMaterno, dia, mes, anio);
     cout <<"Tu RFC sin homoclave es:  "<< rfc <<endl;
     
     return 0;
 }