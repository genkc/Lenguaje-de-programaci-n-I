/******************************************************************************
Programa que permite determinar si una persona es mayor o menor de edad.
autor: Genaro Kantun Can
fecha: 24-07-2025

*******************************************************************************/
#include <iostream>
using namespace std;
int main(){
    int edad;
    char salir;
    do{
        system("clear");
    cout<<"Por favor ingresa tu edad: " <<endl;
    cin >> edad;
    if(edad>=18){
        cout<<"Eres mayor de edad" <<endl;
    }
    else{
        cout<<"Eres menor de edad" <<endl;
    }
    cout << "¿Desea volver a ejecutar?"<<endl;
    cout << "Presione S para si o N para no" <<endl;
    cout <<"S.-Si" <<endl;
    cout <<"N.-No" <<endl;
    cin >> salir;
    }while((salir=='S')||(salir=='s'));
    cout << "Gracias por utilizar el programa" <<endl;
    

    return 0;
}