/******************************************************************************

Programa que realiza las 4 operaciones básicas: suma, resta, multiplicación y división.
autor: Genaro Kantun Can
fecha: 02-08-2025

*******************************************************************************/
#include <iostream>

int main()
{
    float num1, num2, suma, resta, multiplicacion, division;
    char salir;
    do{
        system("clear");
    std:: cout<<"Escribe el primer número: ";
    std:: cin>>num1;
    std:: cout<<"Escribe el segundo número:  ";
    std:: cin>>num2;
    
    suma= num1 + num2;
    resta= num1 - num2;
    multiplicacion= num1 * num2;
  
    std:: cout<<"\nLa suma es: "<<suma<<std:: endl;
    std:: cout<<"La resta es: "<<resta<<std:: endl;
    std:: cout<<"La multiplicación es:  "<<multiplicacion<<std:: endl;
    
    
     if (num2!= 0) {
        division= num1 / num2;
        std::cout << "La division es: " <<division<< std::endl;
    } 
    else {
        std::cout << "Error: No se puede dividir por cero." << std::endl;
    }
   
    std:: cout << "\n¿Desea volver a ejecutar?"<<std:: endl;
    std:: cout << "Presione S para si o N para no" <<std:: endl;
    std:: cout <<"S.-Si" <<std:: endl;
    std:: cout <<"N.-No" <<std:: endl;
    std:: cin >> salir;
    }while((salir=='S')||(salir=='s'));
    system ("clear");
    std:: cout << "Gracias por utilizar el programa, hasta luego" <<std:: endl;
    
    
    return 0;
}